$(document).ready(function() {
    var win = $(window);
    var wrapper = $('.wrapper');
    var body = $(document.body);
    var currentUser = {};



    /*
     ===============================================
     ========================= APPLICATION FUNCTIONS
     */

    ///////////////////*Load Landing Page*////////////////////

    var loadLanding = function(){
        $.get('templates/landing.html', function(htmlArg){
            var headerLand= $(htmlArg).find('#landing_header').html();
            $.template('headertemplate', headerLand);
            var headerland = $.render('', 'headertemplate');
            wrapper.append(headerland);
        });

        $.get('templates/landing.html', function(htmlArg){
            var contentLand= $(htmlArg).find('#landing_content').html();
            $.template('contenttemplate', contentLand);
            var contentland = $.render('', 'contenttemplate');
            wrapper.append(contentland);
        });

        $.get('templates/landing.html', function(htmlArg){
            var footerLand= $(htmlArg).find('#landing_footer').html();
            $.template('footertemplate', footerLand);
            var footerland = $.render('', 'footertemplate');
            wrapper.append(footerland);
        });

    };

    ///////////////////////*Load App/Projects*////////////////


    var loadApp= function(){
        wrapper.empty();
        $.get('templates/app.html', function(htmlArg){
            var headerApp= $(htmlArg).find('#app_header').html();
            $.template('headertemplate', headerApp);
            var headerapp= $.render('', 'headertemplate');
            wrapper.append(headerapp);

        });



        $.get('templates/app.html', function(htmlArg){
            var contentApp= $(htmlArg).find('#app_content').html();
            $.template('contenttemplate', contentApp);
            var contentapp= $.render('', 'contenttemplate');
            wrapper.append(contentapp);

        });

        getProjects();



    };

    /*===================Get Projects========================*/

    var getProjects = function(){
        $.ajax({
            url: 'xhr/get_projects.php',
            type: 'get',
            dataType: 'json',
            success: function(response){
                if(response.error){
                }else{
                    console.log(response);
                    $.get('templates/app.html', function(htmlArg){
                        var projectList= $(htmlArg).find('#app_projects').html();
                        $.template('projectList-template', projectList);

                        for(var i=0; i<response.projects.length; i++){
                            //console.log(response.projects[i].clientID);
                            var projectlist= $.render(response.projects[i], 'projectList-template');
                            $('.list-container').append(projectlist);

                        }
                        /*Accordion*/

                        $('.list-container').jacc({
                            header: '.list',
                            content: '.content',
                            easing: 'easeOutCirc',
                            duration: 1000
                        });

                    });

                }
            }
        });
        return false;
    };



    ///////////////////////* Load New Projects Form*////////////////


    var loadNewProject= function(){
        wrapper.empty();
        $.get('templates/app.html', function(htmlArg){
            var headerApp= $(htmlArg).find('#app_header').html();
            $.template('headertemplate', headerApp);
            var headerapp= $.render('', 'headertemplate');
            wrapper.append(headerapp);

        });



        $.get('templates/add-project.html', function(htmlArg){
            var loadProjectForm= $(htmlArg).find('#add-project').html();
            $.template('add-project-template', loadProjectForm);
            var loadprojectform= $.render('', 'add-project-template');
            wrapper.append(loadprojectform);

            /*Date Picker*/

            $( "#datepicker" ).datepicker();


        });

    };

    /*===================Add Project========================*/


    $('.add-project').live('click', function(e){
        var name = $('.project-name').val();
        var description = $('.text-area').val();
        var date= $('#datepicker').val();
        var status= $('.my_select_box').val();
        $.ajax({
            url: 'xhr/new_project.php',
            data:{
                projectName: name,
                status: status,
                projectDescription: description,
                dueDate: date
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){

                }else{
                    loadApp();
                }
            }
        });

        return false;
    });


    ///////////////////////* Load Edit Project Form*////////////////
    ////////////////////////////////////////////////////////////////

    var loadEditProject= function(projectID, projectName, textArea){
        wrapper.empty();
        $.get('templates/app.html', function(htmlArg){
            var headerApp= $(htmlArg).find('#app_header').html();
            $.template('headertemplate', headerApp);
            var headerapp= $.render('', 'headertemplate');
            wrapper.append(headerapp);

        });



        $.get('templates/edit-project.html', function(htmlArg){
            var loadEditProjectForm= $(htmlArg).find('#edit-project').html();
            $.template('edit-project-template', loadEditProjectForm);
            var loadeditprojectform= $.render('', 'edit-project-template');
            wrapper.append(loadeditprojectform);

            $('.projectid').val(projectID);
            $('.project-name').val(projectName);
            $('.text-area').val(textArea);

            /*Date Picker*/

            $( "#datepicker" ).datepicker();

        });

    };

    /*===================Edit Project========================*/


    $('#update-project').live('click', function(e){
        var name = $('.project-name').val();
        var description = $('.text-area').val();
        var date= $('#datepicker').val();
        var status= $('.my_select_box').val();
        var projectid= $('.projectid').val();

        console.log(projectid);
        $.ajax({
            url: 'xhr/update_project.php',
            data:{
                projectName: name,
                status: status,
                projectDescription: description,
                dueDate: date,
                projectID: projectid
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){

                }else{
                    loadApp();
                }
            }
        });

        return false;
    });



    ///////////////////*Load App/Tasks*/////////////////


    var loadTasks= function(projectID){
        wrapper.empty();
        $.get('templates/tasks.html', function(htmlArg){
            var headerTasks= $(htmlArg).find('#tasks_header').html();
            $.template('headertemplate', headerTasks);
            var headertasks= $.render('', 'headertemplate');
            wrapper.append(headertasks);
        });



        $.get('templates/tasks.html', function(htmlArg){
            var contentTasks= $(htmlArg).find('#tasks_content').html();
            $.template('contenttemplate', contentTasks);
            var contenttasks= $.render('', 'contenttemplate');
            wrapper.append(contenttasks);

            $('.projectid').val(projectID);

        });

        getTasks(projectID);


    };

    /*===================Get Tasks========================*/

    var getTasks = function(projectID){
        $.ajax({
            url: 'xhr/get_tasks.php',
            type: 'get',
            dataType: 'json',
            data: {
                projectID: projectID
            },
            success: function(response){
                if(response.error){
                }else{
                    console.log(response);
                    $.get('templates/tasks.html', function(htmlArg){
                        var taskList= $(htmlArg).find('#tasks_list').html();
                        $.template('taskList-template', taskList);
                        //console.log(taskList);
                        for(var i=0; i<response.tasks.length; i++){
                            console.log(response.tasks[i]);
                            var tasklist = $.render(response.tasks[i], 'taskList-template');
                            $('.list-container').append(tasklist);

                        }
                        /*Accordion*/

                        $('.list-container').jacc({
                            header: '.list',
                            content: '.content',
                            easing: 'easeOutCirc',
                            duration: 1000
                        });



                    });

                }
            }
        });
        return false;
    };


    ///////////////////////* Load New Tasks Form*////////////////


    var loadNewTask= function(projectID){
        wrapper.empty();
        $.get('templates/app.html', function(htmlArg){
            var headerApp= $(htmlArg).find('#app_header').html();
            $.template('headertemplate', headerApp);
            var headerapp= $.render('', 'headertemplate');
            wrapper.append(headerapp);

        });



        $.get('templates/add-task.html', function(htmlArg){
            var loadTaskForm= $(htmlArg).find('#add-task').html();
            $.template('add-task-template', loadTaskForm);
            var loadtaskform= $.render('', 'add-task-template');
            wrapper.append(loadtaskform);

            $('.projectid').val(projectID);

            /*Date Picker*/

            $( "#datepicker" ).datepicker();

        });

    };

    /*===================Add Task========================*/


    $('.add-task').live('click', function(e){
        var name = $('.task-name').val();
        var description = $('.text-area').val();
        var date= $('#datepicker').val();
        var status= $('.my_select_box').val();
        console.log(status);
        var projectid= $('.projectid').val();
        $.ajax({
            url: 'xhr/new_task.php',
            data:{
                taskName: name,
                status: status,
                taskDescription: description,
                dueDate: date,
                projectID: projectid
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){

                }else{
                    loadTasks(projectid);
                }
            }
        });

        return false;
    });


    ///////////////////////* Load Edit Task Form *////////////////
    ////////////////////////////////////////////////////////////////

    var loadEditTask= function(taskID, taskName, textArea){
        wrapper.empty();
        $.get('templates/app.html', function(htmlArg){
            var headerApp= $(htmlArg).find('#app_header').html();
            $.template('headertemplate', headerApp);
            var headerapp= $.render('', 'headertemplate');
            wrapper.append(headerapp);

        });



        $.get('templates/edit-task.html', function(htmlArg){
            var loadEditTaskForm= $(htmlArg).find('#edit-task').html();
            $.template('edit-task-template', loadEditTaskForm);
            var loadedittaskform= $.render('', 'edit-task-template');
            wrapper.append(loadedittaskform);

            $('.taskid').val(taskID);
            $('.task-name').val(taskName);
            $('.text-area').val(textArea);

            /*Date Picker*/

            $( "#datepicker" ).datepicker();

        });

    };

    /*===================Edit Task========================*/


    $('#update-task').live('click', function(e){
        var name = $('.project-name').val();
        var description = $('.text-area').val();
        var date= $('#datepicker').val();
        var status= $('.my_select_box').val();
        var taskid= $('.taskid').val();
        $.ajax({
            url: 'xhr/update_task.php',
            data:{
                projectName: name,
                status: status,
                projectDescription: description,
                dueDate: date,
                taskID: taskid
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){

                }else{
                    loadTasks();
                }
            }
        });

        return false;
    });





    //////////////////*Check log in state*///////////////////////


    var checkLoginState = function(){
        $.ajax({
            url: 'xhr/check_login.php',
            type: 'get',
            dataType: 'json',
            success: function(response){
                if(response.error){

                    wrapper.empty();
                    loadLanding();

                }else{

                    wrapper.empty();
                    loadApp();
                }
            }
        });
    };

    // 	============================================
    //	SETUP FOR INIT

    var init = function(){
        checkLoginState();
    };

    init();



    /*
     ===============================================
     ======================================== EVENTS
     */

    /*Login event*/

    $('#submit-login').live('click', function(e){
        e.preventDefault();
        var user = $('#login-usr').val();
        var pass = $('#login-pss').val();


        $.ajax({
            url: 'xhr/login.php',
            data:{
                username: user,
                password: pass
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){
                    var n = noty({
                        text: 'Your Username/Password is incorrect... Please try again!',
                        type: 'error'
                    });
                }else{
                    loadApp();
                }
            }
        });

        return false;
    });


    /*Register event*/

    $('#submit-reg').live('click', function(e){
        var user = $('#reg-usr').val();
        var pass = $('#reg-pss').val();
        var email= $('#reg-email').val();
        $.ajax({
            url: 'xhr/register.php',
            data:{
                username: user,
                password: pass,
                email: email
            },
            type: 'post',
            dataType: 'json',
            success: function(response){
                if(response.error){
                    var n = noty({
                        text: 'Your Username/E-mail already exist... Please try again!',
                        type: 'error'
                    });
                }else{
                    loadApp();
                }
            }
        });

        return false;
    });

    /*Log Out event*/

    $('.logout').live('click', function(e){
        $.get('xhr/logout.php', function(){
            wrapper.empty();
            loadLanding();
        });
        return false
    });

    /*Projects Link event*/


    $('#projects-link').live('click', function(e){
        $.get('templates/app.html', function(){
            wrapper.empty();
            loadApp();
        });
        return false
    });

    /*Load Tasks Link event*/


    $('.tasksBtn').live('click', function(e){
        wrapper.empty();
        var projectID = $(this).next('.projectid').val();
        loadTasks(projectID);
        return false
    });



    /*Add Project event*/


    $('#add-project').live('click', function(e){
        $.get('templates/add-project.html', function(){
            wrapper.empty();
            loadNewProject();
        });

    });

    /*Add Task event*/

    $('#add-task').live('click', function(e){
        console.log(e);
        var projectID = $('.projectid').val();

        $.get('templates/add-task.html', function(){
            wrapper.empty();
            loadNewTask(projectID);
        });

    });

    /*Edit Project event*/

    $('.edit-project-icon').live('click', function(e){
        var projectID= $(this).prev('.projectid').val();
        var projectName= $(this).parent().prev().find('.name').html();
        var textArea= $(this).parent().find('#description').html();

        loadEditProject(projectID, projectName, textArea);
        return false
    });

    /*Edit Task event*/

    $('.edit-task-icon').live('click', function(e){
        var taskID= $(this).prev('.taskid').val();
        var taskName= $(this).parent().prev().find('.name').html();
        var textArea= $(this).parent().find('#description').html();

        loadEditTask(taskID, taskName, textArea);
        return false
    });

});

